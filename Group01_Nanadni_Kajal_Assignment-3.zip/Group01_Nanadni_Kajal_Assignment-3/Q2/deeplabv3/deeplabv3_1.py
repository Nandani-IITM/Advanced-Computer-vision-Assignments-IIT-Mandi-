import torch
import torchvision.transforms as transforms
from PIL import Image

# Load the DeepLabV3 model
seg_model = torch.hub.load('pytorch/vision:v0.10.0', 'deeplabv3_resnet50', pretrained=True)
seg_model.eval()

# Define transforms for preprocessing
preprocess = transforms.Compose([
    transforms.Resize((513, 513)),  # Resize to match the model's input size
    transforms.Grayscale(num_output_channels=3),  # Convert single-channel image to three-channel
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
])

def segment_image(image_path, save_path):
    # Load and preprocess the input image
    input_image = Image.open(image_path)
    input_tensor = preprocess(input_image).unsqueeze(0)

    # Perform inference
    with torch.no_grad():
        output = seg_model(input_tensor)['out'][0]  # Accessing the 'out' key of the output dictionary

    # Convert the output to a segmentation mask with a single channel per class
    # Assuming the model output contains softmax probabilities for each class
    segmentation_mask = torch.argmax(output, dim=0).byte()

    # Convert the segmentation mask tensor to PIL Image
    segmented_image = transforms.ToPILImage()(segmentation_mask.cpu())

    # Save the segmented image
    segmented_image.save(save_path)

# Test the model on an example image and save the segmented image
image_path = "/storage/kajal/ACV_Assign/assign_3&4/00000003_003.png"
save_path = "/storage/kajal/ACV_Assign/assign_3&4/segmented_image.png"
segment_image(image_path, save_path)

