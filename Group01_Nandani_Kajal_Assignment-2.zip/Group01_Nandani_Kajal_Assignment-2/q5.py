from collections import defaultdict

class BytePairEncoding:
    def __init__(self):
        self.vocab = defaultdict(int)
        self.token_freq = defaultdict(int)
        self.token_prob = defaultdict(float)

    def tokenize(self, corpus):
        tokens = []
        for word in corpus:
            tokens.extend(list(word))
            tokens.append(' ')
        return tokens[:-1]

    def build_vocab_freq(self, tokens):
        for i in range(len(tokens) - 1):
            self.vocab[(tokens[i], tokens[i+1])] += 1

    def build_vocab_prob(self, tokens):
        total_pairs = sum(self.vocab.values())
        for pair, freq in self.vocab.items():
            self.token_prob[pair] = freq / total_pairs

    def merge_tokens_freq(self):
        if not self.vocab:
            return
        max_pair = max(self.vocab, key=self.vocab.get)
        merged_token = ''.join(max_pair)
        self.vocab.pop(max_pair)
        self.token_freq[merged_token] = self.vocab[max_pair]
        self._update_vocab(max_pair, merged_token)

    def merge_tokens_prob(self):
        if not self.token_prob:
            return
        max_pair = max(self.token_prob, key=self.token_prob.get)
        merged_token = ''.join(max_pair)
        self.token_prob.pop(max_pair)
        self.token_freq[merged_token] = self.vocab[max_pair]
        self._update_vocab(max_pair, merged_token)

    def _update_vocab(self, max_pair, merged_token):
        new_vocab = defaultdict(int)
        for key, value in self.vocab.items():
            if max_pair[0] in key or max_pair[1] in key:
                continue
            new_key = key[0] if key[0] != max_pair[0] else merged_token
            new_key += key[1] if key[1] != max_pair[1] else merged_token
            new_vocab[new_key] = value
        self.vocab = new_vocab

    def fit(self, corpus=None, method='freq', num_merges=100):
        if corpus is None:
            raise ValueError("Corpus cannot be None. Please provide a corpus.")
        tokens = self.tokenize(corpus)
        self.build_vocab_freq(tokens)
        if method == 'freq':
            for _ in range(num_merges):
                self.merge_tokens_freq()
        elif method == 'prob':
            self.build_vocab_prob(tokens)
            for _ in range(num_merges):
                self.merge_tokens_prob()
        else:
            raise ValueError("Method should be 'freq' or 'prob'.")

    def read_data(self, file_path):
        with open(file_path, 'r') as file:
            data = file.read().splitlines()
        return data

    def continuation_score(self, corpus):
        tokens = self.tokenize(corpus)
        tokenized_corpus = self.tokenize(corpus)
        lcp_sum = 0
        for i in range(len(tokenized_corpus) - 1):
            token1, token2 = tokenized_corpus[i], tokenized_corpus[i+1]
            lcp = 0
            for char1, char2 in zip(token1, token2):
                if char1 == char2:
                    lcp += 1
                else:
                    break
            lcp_sum += lcp
        return lcp_sum / len(tokenized_corpus)

    def fertility(self):
        return len(self.token_freq)


bpe = BytePairEncoding()


train_file_path = '/content/drive/MyDrive/D22180_ACV/Group01_Nandani_Kajal_Assignment-2/train_dataset.txt'
val_file_path = '/content/drive/MyDrive/D22180_ACV/Group01_Nandani_Kajal_Assignment-2/val_dataset.txt'
test_file_path = '/content/drive/MyDrive/D22180_ACV/Group01_Nandani_Kajal_Assignment-2/test_dataset.txt'


train_corpus = bpe.read_data(train_file_path)


bpe.fit(train_corpus, method='freq', num_merges=5)


continuation = bpe.continuation_score(train_corpus)
print("Continuation Score:", continuation)


fertility = bpe.fertility()
print("Fertility:", fertility)




class BytePairEncoding:
    def __init__(self):
        self.vocab = defaultdict(int)
        self.token_freq = defaultdict(int)
        self.token_prob = defaultdict(float)

    def tokenize(self, corpus):
        tokens = []
        for word in corpus:
            tokens.extend(list(word))
            tokens.append(' ')
        return tokens[:-1]  # Remove the last space

    def build_vocab_freq(self, tokens):
        for i in range(len(tokens) - 1):
            self.vocab[(tokens[i], tokens[i+1])] += 1

    def build_vocab_prob(self, tokens):
        total_pairs = sum(self.vocab.values())
        for pair, freq in self.vocab.items():
            self.token_prob[pair] = freq / total_pairs

    def merge_tokens_freq(self):
        if not self.vocab:
            return
        max_pair = max(self.vocab, key=self.vocab.get)
        merged_token = ''.join(max_pair)
        self.vocab.pop(max_pair)
        self.token_freq[merged_token] = self.vocab[max_pair]
        self._update_vocab(max_pair, merged_token)

    def merge_tokens_prob(self):
        if not self.token_prob:
            return
        max_pair = max(self.token_prob, key=self.token_prob.get)
        merged_token = ''.join(max_pair)
        self.token_prob.pop(max_pair)
        self.token_freq[merged_token] = self.vocab[max_pair]
        self._update_vocab(max_pair, merged_token)

    def _update_vocab(self, max_pair, merged_token):
        new_vocab = defaultdict(int)
        for key, value in self.vocab.items():
            if max_pair[0] in key or max_pair[1] in key:
                continue
            new_key = key[0] if key[0] != max_pair[0] else merged_token
            new_key += key[1] if key[1] != max_pair[1] else merged_token
            new_vocab[new_key] = value
        self.vocab = new_vocab

    def fit(self, corpus=None, method='freq', num_merges=100):
        if corpus is None:
            raise ValueError("Corpus cannot be None. Please provide a corpus.")
        tokens = self.tokenize(corpus)
        self.build_vocab_freq(tokens)
        if method == 'freq':
            for _ in range(num_merges):
                self.merge_tokens_freq()
        elif method == 'prob':
            self.build_vocab_prob(tokens)
            for _ in range(num_merges):
                self.merge_tokens_prob()
        else:
            raise ValueError("Method should be 'freq' or 'prob'.")

    def read_data(self, file_path):
        with open(file_path, 'r') as file:
            data = file.read().splitlines()
        return data

    def get_vocab(self):
        return list(self.token_freq.keys())

# Example usage:
bpe = BytePairEncoding()
train_corpus = bpe.read_data('/content/drive/MyDrive/D22180_ACV/Group01_Nandani_Kajal_Assignment-2/train_dataset.txt')
bpe.fit(train_corpus, method='freq', num_merges=5)
print("Vocabulary using frequencies:", bpe.get_vocab())

bpe = BytePairEncoding()
bpe.fit(train_corpus, method='prob', num_merges=5)
print("Vocabulary using probabilities:", bpe.get_vocab())

