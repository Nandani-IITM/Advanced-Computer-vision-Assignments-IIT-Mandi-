import numpy as np
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout, Embedding
from tensorflow.keras.preprocessing.sequence import pad_sequences
import matplotlib.pyplot as plt


train_data_path = "/storage/nandani/Group01_Nandani_Kajal_Assignment-2/train_dataset.txt"
val_data_path = "/storage/nandani/Group01_Nandani_Kajal_Assignment-2/val_dataset.txt"
test_data_path = "/storage/nandani/Group01_Nandani_Kajal_Assignment-2/test_dataset.txt"

with open(train_data_path, "r") as f:
    train_data = f.read().split("\n\n")

with open(val_data_path, "r") as f:
    val_data = f.read().split("\n\n")

with open(test_data_path, "r") as f:
    test_data = f.read().split("\n\n")


def preprocess_text(data):
    text = " ".join(data)
    chars = sorted(set(text))
    char_to_idx = {char: idx for idx, char in enumerate(chars)}
    idx_to_char = {idx: char for char, idx in char_to_idx.items()}
    sequences = [char_to_idx[char] for char in text]
    return sequences, char_to_idx, idx_to_char


train_sequences, char_to_idx, idx_to_char = preprocess_text(train_data)
val_sequences, _, _ = preprocess_text(val_data)


def generate_training_data(sequences, seq_length):
    inputs = []
    targets = []
    for i in range(len(sequences) - seq_length):
        inputs.append(sequences[i:i + seq_length])
        targets.append(sequences[i + seq_length])
    return np.array(inputs), np.array(targets)


seq_length = 100
X_train, y_train = generate_training_data(train_sequences, seq_length)
X_val, y_val = generate_training_data(val_sequences, seq_length)


vocab_size = len(char_to_idx)
embedding_dim = 256
lstm_units = 256
model = Sequential([
    Embedding(vocab_size, embedding_dim, input_length=seq_length),
    LSTM(lstm_units),
    Dense(vocab_size, activation='softmax')
])


model.compile(loss='sparse_categorical_crossentropy', optimizer='adam')


early_stopping = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=3, restore_best_weights=True)


history = model.fit(X_train, y_train, validation_data=(X_val, y_val), epochs=30, batch_size=128, callbacks=[early_stopping])

plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()
plt.show()

test_sequences, _, _ = preprocess_text(test_data)
X_test, y_test = generate_training_data(test_sequences, seq_length)
test_loss = model.evaluate(X_test, y_test)
test_perplexity = np.exp(test_loss)
print("Perplexity on Test Data:", test_perplexity)

