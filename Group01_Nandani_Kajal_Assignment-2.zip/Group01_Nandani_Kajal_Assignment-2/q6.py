import numpy as np
import tensorflow as tf
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

# Sample corpus
corpus = ["king is a strong man",
          "queen is a wise woman",
          "boy is a young man",
          "girl is a young woman",
          "prince is a young king",
          "princess is a young queen",
          "man is strong",
          "woman is pretty",
          "king is married to queen",
          "queen rules the kingdom"]

# Tokenizing the corpus
words = []
for sentence in corpus:
    words.extend(sentence.split())

# Creating vocabulary
vocab = set(words)
word_to_idx = {word: idx for idx, word in enumerate(vocab)}
idx_to_word = {idx: word for word, idx in word_to_idx.items()}
vocab_size = len(vocab)

# Generate skip-gram pairs
window_size = 2
skip_grams = []
for sentence in corpus:
    sentence_tokens = sentence.split()
    for i, target_word in enumerate(sentence_tokens):
        for j in range(max(0, i - window_size), min(len(sentence_tokens), i + window_size + 1)):
            if i != j:
                context_word = sentence_tokens[j]
                skip_grams.append((target_word, context_word))

# Define the skip-gram model
embedding_dim = 100
inputs = tf.keras.layers.Input(shape=(1,))
embedding_layer = tf.keras.layers.Embedding(vocab_size, embedding_dim)(inputs)
flatten_layer = tf.keras.layers.Flatten()(embedding_layer)
output = tf.keras.layers.Dense(vocab_size, activation='softmax')(flatten_layer)
model = tf.keras.Model(inputs=inputs, outputs=output)

# Compile the model
model.compile(loss='sparse_categorical_crossentropy', optimizer='adam')

# Train the model
target_words = [word_to_idx[w] for w, _ in skip_grams]
context_words = [word_to_idx[w] for _, w in skip_grams]
model.fit(np.array(target_words), np.array(context_words), epochs=50, batch_size=32)

# Extracting the word embeddings
embeddings = model.layers[1].get_weights()[0]

# Find similar words using the learned embeddings
def find_similar_words(word, top_n=5):
    if word not in word_to_idx:
        print("Word not found in vocabulary!")
        return
    word_idx = word_to_idx[word]
    word_embedding = embeddings[word_idx]
    cosine_similarities = np.dot(embeddings, word_embedding) / (np.linalg.norm(embeddings, axis=1) * np.linalg.norm(word_embedding))
    most_similar_indices = np.argsort(cosine_similarities)[::-1][:top_n]
    most_similar_words = [idx_to_word[idx] for idx in most_similar_indices]
    return most_similar_words

# Test relations like King - Queen + Man = Woman
relation_words = ["king", "queen", "man", "woman"]
relation_vector = embeddings[word_to_idx["king"]] - embeddings[word_to_idx["queen"]] + embeddings[word_to_idx["woman"]]
relation_similar_words = [find_similar_words(word) for word in relation_words]
print("Relation: King - Queen + Man = Woman")
for i in range(len(relation_words)):
    print(relation_words[i], ":", relation_similar_words[i])

# Visualize word embeddings using t-SNE
def plot_embeddings(embeddings, words):
    tsne = TSNE(n_components=2, random_state=42, perplexity=min(len(words)//2, 30))
    embedding_tsne = tsne.fit_transform(embeddings)
    plt.figure(figsize=(10, 8))
    for i in range(len(words)):
        plt.scatter(embedding_tsne[i, 0], embedding_tsne[i, 1])
        plt.annotate(words[i], (embedding_tsne[i, 0], embedding_tsne[i, 1]))
    plt.xlabel("t-SNE Component 1")
    plt.ylabel("t-SNE Component 2")
    plt.title("t-SNE Visualization of Word Embeddings")
    plt.show()

# Visualize embeddings and find clusters
plot_embeddings(embeddings, list(vocab))

import numpy as np
import tensorflow as tf
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

def read_data(file_path):
    with open(file_path, 'r') as file:
        data = file.read().splitlines()
    return data

train_corpus = read_data('/storage/nandani/Group01_Nandani_Kajal_Assignment-2/train_dataset.txt')
val_corpus = read_data('/storage/nandani/Group01_Nandani_Kajal_Assignment-2/val_dataset.txt')
test_corpus = read_data('/storage/nandani/Group01_Nandani_Kajal_Assignment-2/test_dataset.txt')



corpus = train_corpus + val_corpus + test_corpus
words = []
for sentence in corpus:
    words.extend(sentence.split())


vocab = set(words)
word_to_idx = {word: idx for idx, word in enumerate(vocab)}
idx_to_word = {idx: word for word, idx in word_to_idx.items()}
vocab_size = len(vocab)


def generate_skipgrams(corpus, window_size):
    skip_grams = []
    for sentence in corpus:
        sentence_tokens = sentence.split()
        for i, target_word in enumerate(sentence_tokens):
            for j in range(max(0, i - window_size), min(len(sentence_tokens), i + window_size + 1)):
                if i != j:
                    context_word = sentence_tokens[j]
                    skip_grams.append((target_word, context_word))
    return skip_grams


window_size = 2
skip_grams = generate_skipgrams(train_corpus, window_size)


embedding_dim = 100
inputs = tf.keras.layers.Input(shape=(1,))
embedding_layer = tf.keras.layers.Embedding(vocab_size, embedding_dim)(inputs)
flatten_layer = tf.keras.layers.Flatten()(embedding_layer)
output = tf.keras.layers.Dense(vocab_size, activation='softmax')(flatten_layer)
model = tf.keras.Model(inputs=inputs, outputs=output)


model.compile(loss='sparse_categorical_crossentropy', optimizer='adam')


target_words = [word_to_idx[w] for w, _ in skip_grams]
context_words = [word_to_idx[w] for _, w in skip_grams]
model.fit(np.array(target_words), np.array(context_words), epochs=5, batch_size=32)

embeddings = model.layers[1].get_weights()[0]


val_similar_words = {}
for word in vocab:
    similar_words = find_similar_words(word)
    val_similar_words[word] = similar_words


plot_embeddings(embeddings, list(vocab))


test_similar_words = {}
for word in vocab:
    similar_words = find_similar_words(word)
    test_similar_words[word] = similar_words

plot_embeddings(embeddings, list(vocab))

