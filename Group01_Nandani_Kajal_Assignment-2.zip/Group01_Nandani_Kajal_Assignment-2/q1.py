#q1-a-b

import requests
import random
from collections import defaultdict
import math
import numpy as np


url = "https://ocw.mit.edu/ans7870/6/6.006/s08/lecturenotes/files/t8.shakespeare.txt"
response = requests.get(url)
data = response.text

paragraphs = data.split("\n\n")


random.shuffle(paragraphs)


total_paragraphs = len(paragraphs)
train_size = int(0.8 * total_paragraphs)
val_size = int(0.1 * total_paragraphs)
test_size = total_paragraphs - train_size - val_size

train_data = paragraphs[:train_size]
val_data = paragraphs[train_size:train_size + val_size]
test_data = paragraphs[train_size + val_size:]

with open("/content/drive/MyDrive/D22180_ACV/Group01_Nandani_Kajal_Assignment-2/train_dataset.txt", "w") as f:
    f.write("\n\n".join(train_data))

with open("/content/drive/MyDrive/D22180_ACV/Group01_Nandani_Kajal_Assignment-2/val_dataset.txt", "w") as f:
    f.write("\n\n".join(val_data))

with open("/content/drive/MyDrive/D22180_ACV/Group01_Nandani_Kajal_Assignment-2/test_dataset.txt", "w") as f:
    f.write("\n\n".join(test_data))

print("Datasets saved successfully.")

#q1-c

def load_dataset(file_path):
    with open(file_path, "r") as f:
        return f.read().split("\n\n")

train_data = load_dataset("/content/drive/MyDrive/D22180_ACV/Group01_Nandani_Kajal_Assignment-2/train_dataset.txt")
val_data = load_dataset("/content/drive/MyDrive/D22180_ACV/Group01_Nandani_Kajal_Assignment-2/val_dataset.txt")
test_data = load_dataset("/content/drive/MyDrive/D22180_ACV/Group01_Nandani_Kajal_Assignment-2/test_dataset.txt")


def generate_ngrams(text, n):
    words = text.split()
    ngrams = [tuple(words[i:i + n]) for i in range(len(words) - n + 1)]
    return ngrams

def count_bigrams(data, r):
    bigram_counts = defaultdict(int)
    for paragraph in data:
        ngrams = generate_ngrams(paragraph, 2)
        for bigram in ngrams:
            if bigram[1] not in bigram_counts or bigram_counts[bigram[1]] < r:
                bigram_counts[bigram] += 1
    return len(bigram_counts)


def calculate_oov_percentage(train_data, val_data, test_data):
    train_words = set(word for paragraph in train_data for word in paragraph.split())
    val_words = set(word for paragraph in val_data for word in paragraph.split())
    test_words = set(word for paragraph in test_data for word in paragraph.split())

    oov_val = len(val_words - train_words) / len(train_words) * 100
    oov_test = len(test_words - train_words) / len(train_words) * 100

    return oov_val, oov_test

print("r\tTrain Bigrams\tValidation Bigrams\tTest Bigrams")
for r in range(1, 11):
    train_bigrams = count_bigrams(train_data, r)
    val_bigrams = count_bigrams(val_data, r)
    test_bigrams = count_bigrams(test_data, r)
    print(f"{r}\t{train_bigrams}\t\t{val_bigrams}\t\t{test_bigrams}")

oov_val_percentage, oov_test_percentage = calculate_oov_percentage(train_data, val_data, test_data)
print("\nPercentage of Out-of-Vocabulary Words:")
print(f"Validation Data: {oov_val_percentage}%")
print(f"Test Data: {oov_test_percentage}%")

#q1-d


def calculate_unigram_probabilities(data):
    word_counts = defaultdict(int)
    total_words = 0


    for paragraph in data:
        for word in paragraph.split():
            word_counts[word] += 1
            total_words += 1


    unigram_probabilities = {word: count / total_words for word, count in word_counts.items()}
    return unigram_probabilities


def calculate_perplexity(test_data, unigram_probabilities):
    total_log_prob = 0
    total_words = 0


    for paragraph in test_data:
        for word in paragraph.split():
            total_log_prob += math.log(unigram_probabilities.get(word, 1e-10))
            total_words += 1


    perplexity = math.exp(-total_log_prob / total_words)
    return perplexity


unigram_probabilities = calculate_unigram_probabilities(train_data)


perplexity = calculate_perplexity(test_data, unigram_probabilities)
print("Perplexity of the Unigram Model on Test Data:", perplexity)

#q1-e


def calculate_bigram_probabilities(data, smoothing=1):
    bigram_counts = defaultdict(lambda: defaultdict(int))
    unigram_counts = defaultdict(int)


    for paragraph in data:
        words = paragraph.split()
        if len(words) > 1:
            bigram_counts['<s>'][words[0]] += 1
            for i in range(1, len(words)):
                bigram_counts[words[i - 1]][words[i]] += 1
                unigram_counts[words[i - 1]] += 1
            unigram_counts[words[-1]] += 1


    vocab_size = len(unigram_counts)
    bigram_probabilities = defaultdict(lambda: defaultdict(float))
    for prev_word, next_words in bigram_counts.items():
        for next_word, count in next_words.items():
            bigram_probabilities[prev_word][next_word] = (count + smoothing) / (unigram_counts[prev_word] + smoothing * vocab_size)
    return bigram_probabilities


def calculate_perplexity_bigram(test_data, bigram_probabilities):
    total_log_prob = 0
    total_words = 0


    for paragraph in test_data:
        words = paragraph.split()
        if len(words) > 1:
            total_log_prob += np.log(bigram_probabilities['<s>'].get(words[0], 1e-10))
            total_words += 1
            for i in range(1, len(words)):
                total_log_prob += np.log(bigram_probabilities[words[i - 1]].get(words[i], 1e-10))
                total_words += 1


    perplexity = np.exp(-total_log_prob / total_words)
    return perplexity


bigram_probabilities = calculate_bigram_probabilities(train_data, smoothing=0.1)


perplexity_bigram = calculate_perplexity_bigram(test_data, bigram_probabilities)
print("Perplexity of the Bigram Model on Test Data:", perplexity_bigram)


sentence = "Rome. Before a gate of the city"


words = sentence.split()
n = len(words)
bigram_matrix = np.zeros((n, n))


for i in range(n):
    for j in range(n):
        if j == 0:
            bigram_matrix[i][j] = bigram_probabilities['<s>'].get(words[i], 0)
        else:
            bigram_matrix[i][j] = bigram_probabilities[words[j - 1]].get(words[i], 0)


print("\nBigram Matrix:")
print(bigram_matrix)

#q1-f

import numpy as np
from collections import defaultdict


def generate_ngrams(text, n):
    words = text.split()
    ngrams = [tuple(words[i:i + n]) for i in range(len(words) - n + 1)]
    return ngrams

def count_bigrams(data):
    bigram_counts = defaultdict(int)
    unigram_counts = defaultdict(int)
    for paragraph in data:
        ngrams = generate_ngrams(paragraph, 2)
        for bigram in ngrams:
            bigram_counts[bigram] += 1
            unigram_counts[bigram[0]] += 1
    return bigram_counts, unigram_counts


def calculate_bigram_probabilities(bigram_counts, unigram_counts):
    bigram_probabilities = defaultdict(float)
    for bigram, count in bigram_counts.items():
        bigram_probabilities[bigram] = count / unigram_counts[bigram[0]]
    return bigram_probabilities


def calculate_perplexity(test_data, bigram_probabilities):
    total_log_prob = 0
    total_words = 0


    for paragraph in test_data:
        ngrams = generate_ngrams(paragraph, 2)
        for bigram in ngrams:
            total_log_prob += np.log(bigram_probabilities.get(bigram, 1e-10))
            total_words += 1


    perplexity = np.exp(-total_log_prob / total_words)
    return perplexity


def load_dataset(file_path):
    with open(file_path, "r") as f:
        return f.read().split("\n\n")

train_data = load_dataset("/content/drive/MyDrive/D22180_ACV/Group01_Nandani_Kajal_Assignment-2/train_dataset.txt")
test_data = load_dataset("/content/drive/MyDrive/D22180_ACV/Group01_Nandani_Kajal_Assignment-2/test_dataset.txt")


bigram_counts, unigram_counts = count_bigrams(train_data)


bigram_probabilities = calculate_bigram_probabilities(bigram_counts, unigram_counts)


perplexity_bigram = calculate_perplexity(test_data, bigram_probabilities)
print("Perplexity of the Bigram Model on Test Data:", perplexity_bigram)


sentence = "Rome. Before a gate of the city"


words = sentence.split()
n = len(words)
bigram_matrix = np.zeros((n, n))


for i in range(n):
    for j in range(n):
        if j == 0:
            bigram_matrix[i][j] = bigram_probabilities.get((words[i],), 0)
        else:
            bigram_matrix[i][j] = bigram_probabilities.get((words[j - 1], words[i]), 0)


print("\nBigram Matrix:")
print(bigram_matrix)


def count_ngrams(data, n):
    ngram_counts = defaultdict(int)
    prefix_counts = defaultdict(int)
    for paragraph in data:
        ngrams = generate_ngrams(paragraph, n)
        for gram in ngrams:
            ngram_counts[gram] += 1
            prefix = gram[:-1]
            prefix_counts[prefix] += 1
    return ngram_counts, prefix_counts


def calculate_ngram_probabilities(ngram_counts, prefix_counts):
    ngram_probabilities = defaultdict(float)
    for ngram, count in ngram_counts.items():
        prefix = ngram[:-1]
        ngram_probabilities[ngram] = count / prefix_counts[prefix]
    return ngram_probabilities

def generate_fill_in_the_blanks_questions(test_data, num_questions=5):
    questions = []
    for paragraph in test_data:
        words = paragraph.split()
        if len(words) > 1:
            blank_index = np.random.randint(0, len(words))
            question = " ".join([word if i != blank_index else "_____" for i, word in enumerate(words)])
            answer = words[blank_index]
            questions.append((question, answer))
            if len(questions) == num_questions:
                break
    return questions


test_data = load_dataset("/content/drive/MyDrive/D22180_ACV/Group01_Nandani_Kajal_Assignment-2/test_dataset.txt")


ngram_counts_2, prefix_counts_2 = count_ngrams(train_data, n=2)
ngram_counts_3, prefix_counts_3 = count_ngrams(train_data, n=3)
ngram_counts_4, prefix_counts_4 = count_ngrams(train_data, n=4)


ngram_probabilities_2 = calculate_ngram_probabilities(ngram_counts_2, prefix_counts_2)
ngram_probabilities_3 = calculate_ngram_probabilities(ngram_counts_3, prefix_counts_3)
ngram_probabilities_4 = calculate_ngram_probabilities(ngram_counts_4, prefix_counts_4)


perplexity_2 = calculate_perplexity(test_data, ngram_probabilities_2)
perplexity_3 = calculate_perplexity(test_data, ngram_probabilities_3)
perplexity_4 = calculate_perplexity(test_data, ngram_probabilities_4)

print("Perplexity of the 2nd Order Model on Test Data:", perplexity_2)
print("Perplexity of the 3rd Order Model on Test Data:", perplexity_3)
print("Perplexity of the 4th Order Model on Test Data:", perplexity_4)


fill_in_the_blanks_questions = generate_fill_in_the_blanks_questions(test_data)
for i, (question, answer) in enumerate(fill_in_the_blanks_questions):
    print(f"\nQuestion {i + 1}:")
    print(question.replace("_____", "[_____]"))
    print("Answer:", answer)


