import numpy as np
from collections import defaultdict

sentence = "Rome. Before a gate of the city"
words = sentence.split()
n = len(words)
bigram_matrix = np.zeros((n, n))



def load_dataset(file_path):
    with open(file_path, "r") as f:
        return f.read().split("\n\n")

train_data = load_dataset("/content/drive/MyDrive/D22180_ACV/Group01_Nandani_Kajal_Assignment-2/train_dataset.txt")
test_data = load_dataset("/content/drive/MyDrive/D22180_ACV/Group01_Nandani_Kajal_Assignment-2/test_dataset.txt")

def generate_fill_in_the_blanks_questions(test_data, num_questions=5):
    questions = []
    for paragraph in test_data:
        words = paragraph.split()
        if len(words) > 1:
            blank_index = np.random.randint(0, len(words))
            question = " ".join([word if i != blank_index else "_____" for i, word in enumerate(words)])
            answer = words[blank_index]
            questions.append((question, answer))
            if len(questions) == num_questions:
                break
    return questions
    
def generate_char_ngrams(text, n):
    char_ngrams = [text[i:i+n] for i in range(len(text) - n + 1)]
    return char_ngrams


def count_char_ngrams(data, n):
    char_ngram_counts = defaultdict(int)
    prefix_counts = defaultdict(int)
    for paragraph in data:
        char_ngrams = generate_char_ngrams(paragraph, n)
        for ngram in char_ngrams:
            char_ngram_counts[ngram] += 1
            prefix = ngram[:-1]
            prefix_counts[prefix] += 1
    return char_ngram_counts, prefix_counts


def calculate_char_ngram_probabilities(char_ngram_counts, prefix_counts):
    char_ngram_probabilities = defaultdict(float)
    for ngram, count in char_ngram_counts.items():
        prefix = ngram[:-1]
        char_ngram_probabilities[ngram] = count / prefix_counts[prefix]
    return char_ngram_probabilities


def calculate_perplexity_char(test_data, char_ngram_probabilities):
    total_log_prob = 0
    total_chars = 0


    for paragraph in test_data:
        char_ngrams = generate_char_ngrams(paragraph, n)
        for ngram in char_ngrams:
            total_log_prob += np.log(char_ngram_probabilities.get(ngram, 1e-10))
            total_chars += 1


    perplexity = np.exp(-total_log_prob / total_chars)
    return perplexity


char_ngram_counts_2, char_prefix_counts_2 = count_char_ngrams(train_data, n=2)
char_ngram_counts_3, char_prefix_counts_3 = count_char_ngrams(train_data, n=3)
char_ngram_counts_4, char_prefix_counts_4 = count_char_ngrams(train_data, n=4)


char_ngram_probabilities_2 = calculate_char_ngram_probabilities(char_ngram_counts_2, char_prefix_counts_2)
char_ngram_probabilities_3 = calculate_char_ngram_probabilities(char_ngram_counts_3, char_prefix_counts_3)
char_ngram_probabilities_4 = calculate_char_ngram_probabilities(char_ngram_counts_4, char_prefix_counts_4)


perplexity_char_2 = calculate_perplexity_char(test_data, char_ngram_probabilities_2)
perplexity_char_3 = calculate_perplexity_char(test_data, char_ngram_probabilities_3)
perplexity_char_4 = calculate_perplexity_char(test_data, char_ngram_probabilities_4)

print("Perplexity of the 2nd Order Character-Level Model on Test Data:", perplexity_char_2)
print("Perplexity of the 3rd Order Character-Level Model on Test Data:", perplexity_char_3)
print("Perplexity of the 4th Order Character-Level Model on Test Data:", perplexity_char_4)


fill_in_the_blanks_questions = generate_fill_in_the_blanks_questions(test_data)
for i, (question, answer) in enumerate(fill_in_the_blanks_questions):
    print(f"\nQuestion {i + 1}:")
    print(question.replace("_____", "[_____]"))
    print("Answer:", answer)
