#mnist_data

import numpy as n
import matplotlib.pyplot as p
from sklearn.datasets import fetch_openml
from sklearn.model_selection import train_test_split

def activation_fun_sig(Z):
    return 1 / (1 + n.exp(-Z))

def MSE(true-y, pred-y):
    return n.mean((true-y - pred-y)**2)

def FP(X, wh, bh, wo, bo):
    hli = n.dot(X, wh) + bh
    hlo = activation_fun_sig(hli)

    oli = n.dot(hlo, wo) + bo
    olo = activation_fun_sig(oli)

    return hlo, olo

def BP(X, true-y, hlo, olo,
                   wh, bh, wo, bo, lr):
    oe = true-y - olo
    od = oe * olo * (1 - olo)

    hle = od.dot(wo.T)
    hld = hle * hlo * (1 - hlo)

    wo += lr * hlo.T.dot(od)
    bo += lr * n.sum(od, axis=0, keepdims=True)

    wh += lr * X.T.dot(hld)
    bh += lr * n.sum(hld, axis=0, keepdims=True)

def tr_model(tr_x, tr_y, te_x, te_y, ip_sz, hd_sz, op_sz, lr, ep):
    n.random.seed(42)
    wh = n.random.randn(ip_sz, hd_sz)
    bh = n.zeros((1, hd_sz))

    wo = n.random.randn(hd_sz, op_sz)
    bo = n.zeros((1, op_sz))

    tr_L = []
    va_L = []

    tr_acc = []
    va_acc = []

    for e in range(ep):

        hlo_train, oplop_tr = FP(tr_x, wh, bh, wo, bo)

        
        tr_l = MSE(tr_y, oplop_tr)
        tr_L.append(tr_l)

        tr_preds = n.argmax(oplop_tr, axis=1)
        tr_ac = n.mean(tr_preds == n.argmax(tr_y, axis=1))
        tr_acc.append(tr_ac)

        hlo_val, oplop_va = FP(te_x, wh, bh, wo, bo)

        
        va_l = MSE(te_y, oplop_va)
        va_L.append(va_l)

        va_preds = n.argmax(oplop_va, axis=1)
        va_ac = n.mean(va_preds == n.argmax(te_y, axis=1))
        va_acc.append(va_ac)

        
        BP(tr_x, tr_y, hlo_train, oplop_tr,
                       wh, bh, wo, bo, lr)

       
        if e % 100 == 0:
            print(f"e {e}, Loss: {tr_l}, tr_model Accuracy: {tr_ac}, Validation Loss: {va_l}, Validation Accuracy: {va_ac}")

    return tr_L, va_L, tr_acc, va_acc, wh, bh, wo, bo



mnist_data = fetch_openml('mnist_784')
X, y = mnist_data.data.astype('float32'), mnist_data.target.astype('int')

X /= 255.0

ncl = 10
1h_y = n.zeros((y.shape[0], ncl))
1h_y[n.arange(y.shape[0]), y] = 1

tr_x, te_x, tr_y, te_y = train_test_split(X, 1h_y, test_size=0.2, random_state=42)

ip_sz = tr_x.shape[1]
hd_sz = 64
op_sz = ncl
lr = 0.00001
ep = 5000

tr_L, va_L, tr_acc, va_acc, wh, bh, wo, bo = tr_model(tr_x, tr_y, te_x, te_y, ip_sz, hd_sz, op_sz, lr, ep)

p.figure(figsize=(10, 5))

p.subplot(1, 2, 1)
p.plot(tr_L, label='Training Loss')
p.plot(va_L, label='Validation Loss')
p.title('Training and Validation Loss Curves')
p.xlabel('epochs')
p.ylabel('Loss')
p.legend()

# Plot the accuracy curves
p.subplot(1, 2, 2)
p.plot(tr_acc, label='Training Accuracy')
p.plot(va_acc, label='Validation Accuracy')
p.title('Training and Validation Accuracy Curves')
p.xlabel('epochs')
p.ylabel('Accuracy')
p.legend()

p.tight_layout()
p.show()

hlo_test, oplop_te = FP(te_x, wh, bh, wo, bo)

preds = n.argmax(oplop_te, axis=1)
Acctual_lab = n.argmax(te_y, axis=1)

acc = n.mean(preds == Acctual_lab)
print(f"Test Accuracy: {acc}")
