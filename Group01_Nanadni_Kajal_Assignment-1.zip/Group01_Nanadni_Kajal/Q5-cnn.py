#AlexNet #VGG16 #GoogLeNet #ResNet152 #EfficientNet-b1 

import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as transforms
import torchvision.models as M
import torch.optim as optim
import time
import matplotlib.pyplot as p

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
])

tr_data = torchvision.datasets.CIFAR10(root='./data', train=True,
                                        download=True, transform=transform)
tr_load = torch.utils.data.DataLoader(tr_data, batch_size=32,
                                          shuffle=True, num_workers=2)

te_data = torchvision.datasets.CIFAR10(root='./data', train=False,
                                       download=True, transform=transform)
te_load = torch.utils.data.DataLoader(te_data, batch_size=32,
                                         shuffle=False, num_workers=2)
alexnet = M.alexnet(pretrained=True)
vgg16 = M.vgg16(pretrained=True)
googlenet = M.googlenet(pretrained=True)
resnet152 = M.resnet152(pretrained=True)
efficientnet_b1 = M.efficientnet_b1(pretrained=True)

ncl = 10
alexnet.classifier[6] = nn.Linear(4096, ncl)
vgg16.classifier[6] = nn.Linear(4096, ncl)
googlenet.fc = nn.Linear(1024, ncl)
resnet152.fc = nn.Linear(2048, ncl)
efficientnet_b1._fc = nn.Linear(1280, ncl)

alexnet.to(device)
vgg16.to(device)
googlenet.to(device)
resnet152.to(device)
efficientnet_b1.to(device)

criterion = nn.CrossEntropyLoss()
opt_alexnet = optim.SGD(alexnet.parameters(), lr=0.001, momentum=0.9)
opt_vgg16 = optim.SGD(vgg16.parameters(), lr=0.001, momentum=0.9)
opt_googlenet = optim.SGD(googlenet.parameters(), lr=0.001, momentum=0.9)
opt_resnet152 = optim.SGD(resnet152.parameters(), lr=0.001, momentum=0.9)
opt_efficientnet_b1 = optim.SGD(efficientnet_b1.parameters(), lr=0.001, momentum=0.9)


models_dict = {
    "AlexNet": alexnet,
    "VGG16": vgg16,
    "GoogLeNet": googlenet,
    "ResNet152": resnet152,
    "EfficientNet-b1": efficientnet_b1
}

p.figure(figsize=(12, 8))

for model_name, M in models_dict.items():
    tr_L_val = []
    va_L_val = []
    va_acc_val = []
    print(f"Training {model_name}...")
    start_time = time.time()
    for epoch in range(5):  
        L_run = 0.0
        for i, data in enumerate(tr_load, 0):
            ips, lbs = data[0].to(device), data[1].to(device)

            optimizer = {
                "AlexNet": opt_alexnet,
                "VGG16": opt_vgg16,
                "GoogLeNet": opt_googlenet,
                "ResNet152": opt_resnet152,
                "EfficientNet-b1": opt_efficientnet_b1
            }[model_name]

            optimizer.zero_grad()

            ops = M(ips)
            L = criterion(ops, lbs)
            L.backward()
            optimizer.step()

            L_run += L.item()
        tr_L_val.append(L_run / len(tr_load))

        
        M.eval()
        va_l = 0.0
        crt = 0
        ttl = 0
        with torch.no_grad():
            for data in te_load:
                I, lbs = data[0].to(device), data[1].to(device)
                ops = M(I)
                L = criterion(ops, lbs)
                va_l += L.item()
                _, predicted = torch.max(ops.data, 1)
                ttl += lbs.size(0)
                crt += (predicted == lbs).sum().item()

        va_L_val.append(va_l / len(te_load))
        va_acc_val.append(crt / ttl)

    end_time = time.time()
    print(f"Finished training {model_name}. Training time: {end_time - start_time} seconds.")

    p.plot(range(1, 6), tr_L_val, label=f"{model_name} Train Loss")
    p.plot(range(1, 6), va_L_val, label=f"{model_name} Validation Loss")
    p.plot(range(1, 6), va_acc_val, label=f"{model_name} Validation Accuracy")

p.xlabel('Epochs')
p.ylabel('Loss / Accuracy')
p.title('Training and Validation Curves')
p.legend()
p.show()
