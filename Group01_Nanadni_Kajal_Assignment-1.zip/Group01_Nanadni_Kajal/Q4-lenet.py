#LeNet

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import pandas as p
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as mpt

class CustomLeNet(nn.Module):
    def __init__(self):
        super(CustomLeNet, self).__init__()
        self.conv1 = nn.Conv2d(1, 6, kernel_size=5, stride=1, padding=2)
        self.relu1 = nn.ReLU()
        self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.conv2 = nn.Conv2d(6, 16, kernel_size=5, stride=1, padding=0)
        self.relu2 = nn.ReLU()
        self.pool2 = nn.MaxPool2d(kernel_size=2, stride=2)
        self.conv3 = nn.Conv2d(16, 120, kernel_size=5, stride=1, padding=0)
        self.relu3 = nn.ReLU()
        self.flatten = nn.Flatten()
        self.fc1 = nn.Linear(120, 84)
        self.relu4 = nn.ReLU()
        self.fc2 = nn.Linear(84, 10)

    def forward(self, Z):
        Z = self.conv1(Z)
        Z = self.relu1(Z)
        Z = self.pool1(Z)
        Z = self.conv2(Z)
        Z = self.relu2(Z)
        Z = self.pool2(Z)
        Z = self.conv3(Z)
        Z = self.relu3(Z)
        Z = self.flatten(Z)
        Z = self.fc1(Z)
        Z = self.relu4(Z)
        Z = self.fc2(Z)
        return Z

def model_train(M, crtn, optm, tr_ldr, va_ldr, ep=10):
    tr_ls = []
    va_ls = []
    tr_accs = []
    va_accs = []

    for e in range(ep):
        M.train()
        tr_l_ep = 0.0
        tr_crt = 0
        tr_ttl = 0

        for ips, tgts in tr_ldr:
            optm.zero_grad()
            ops = M(ips)
            L = crtn(ops, tgts)
            L.backward()
            optm.step()
            tr_l_ep += L.item()

            _, pred = torch.max(ops.data, 1)
            tr_ttl += tgts.size(0)
            tr_crt += (pred == tgts).sum().item()

        tr_L_avg = tr_l_ep / len(tr_ldr)
        tr_acc = tr_crt / tr_ttl
        tr_ls.append(tr_L_avg)
        tr_accs.append(tr_acc)

        M.eval()
        va_L_ep = 0.0
        va_crt = 0
        va_ttl = 0

        with torch.no_grad():
            for ips, tgts in va_ldr:
                ops = M(ips)
                L = crtn(ops, tgts)
                va_L_ep += L.item()

                _, pred = torch.max(ops.data, 1)
                va_ttl += tgts.size(0)
                va_crt += (pred == tgts).sum().item()

        va_L_avg = va_L_ep / len(va_ldr)
        va_acc = va_crt / va_ttl
        va_ls.append(va_L_avg)
        va_accs.append(va_acc)

        print(f'Epoch [{e+1}/{ep}], Train Loss: {tr_L_avg:.4f}, Valid Loss: {va_L_avg:.4f}, Train Accuracy: {tr_acc:.4f}, Valid Accuracy: {va_acc:.4f}')

    return tr_ls, va_ls, tr_accs, va_accs

def visualize_curves(tr_ls, va_ls, tr_accs, va_accs):
    fig, (axis1, axis2) = mpt.subplots(2, 1, figsize=(10, 8))

    axis1.plot(tr_ls, label='Train Loss', color='tab:red')
    axis1.plot(va_ls, label='Valid Loss', linestyle='dashed', color='tab:blue')
    axis1.set_xlabel('Epochs')
    axis1.set_ylabel('Loss')
    axis1.legend()

    axis2.plot(tr_accs, label='Train Accuracy', color='tab:red')
    axis2.plot(va_accs, label='Valid Accuracy', linestyle='dashed', color='tab:blue')
    axis2.set_xlabel('Epochs')
    axis2.set_ylabel('Accuracy')
    axis2.legend()

    mpt.tight_layout()
    mpt.show()



class Data_mnist(Dataset):
    def __init__(self, d, lbs):
        self.d = d #Dataset
        self.lbs = lbs

    def __len__(self):
        return len(self.d)

    def __getitem__(self, idx):
        return self.d[idx], self.lbs[idx]

tr_dFrame = p.read_csv('/storage/nandani/ACV1/mnist_train.csv')
te_dFrame = p.read_csv('/storage/nandani/ACV1/mnist_test.csv')

tr_lbs = tr_dFrame.iloc[:, 0].values
tr_I = tr_dFrame.iloc[:, 1:].values / 255.0  

te_lbs = te_dFrame.iloc[:, 0].values
te_I = te_dFrame.iloc[:, 1:].values / 255.0  

tr_I, va_I, tr_lbs, va_lbs = train_test_split(
    tr_I, tr_lbs, test_size=0.2, random_state=42
)

tr_dt = torch.tensor(tr_I, dtype=torch.float32)
tr_lbs = torch.tensor(tr_lbs, dtype=torch.long)

va_dt = torch.tensor(va_I, dtype=torch.float32)
va_lbs = torch.tensor(va_lbs, dtype=torch.long)

te_dt = torch.tensor(te_I, dtype=torch.float32)
te_lbs = torch.tensor(te_lbs, dtype=torch.long)

bt_sz = 32

tr_dset = Data_mnist(tr_dt, tr_lbs)
tr_ldr = DataLoader(tr_dset, bt_sz=bt_sz, shuffle=True)

va_dset = Data_mnist(va_dt, va_lbs)
va_ldr = DataLoader(va_dset, bt_sz=bt_sz, shuffle=False)

te_dset = Data_mnist(te_dt, te_lbs)
te_ldr = DataLoader(te_dset, bt_sz=bt_sz, shuffle=False)

torch.manual_seed(42)

ip_sz = 784
hd_sz = 64
op_sz = 10

M = CustomLeNet()
crtn = nn.CrossEntropyLoss()
optm = optim.SGD(M.parameters(), lr=0.001)

tr_ls, va_ls, tr_accs, va_accs = model_train(M, crtn, optm, tr_ldr, va_ldr, ep=100)

visualize_curves(tr_ls, va_ls, tr_accs, va_accs)

M.eval()
crt = 0
ttl = 0
with torch.no_grad():
    for ips, lbs in te_ldr:
        ops = M(ips)
        _, pred = torch.max(ops, 1)
        ttl += lbs.size(0)
        crt += (pred == lbs).sum().item()

accuracy = crt / ttl
print(f'Test Accuracy: {accuracy:.4f}')










