#Face-Non-Face
import os
import shutil
import cv2
import numpy as n
import pandas as p
from sklearn.model_selection import train_test_split
from skimage import feature
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
from google.colab.patches import cv2_imshow

def spt_I(src_dir, tr, te, va, te_sz=0.1, va_sz=0.2):
    os.makedirs(tr, exist_ok=True)
    os.makedirs(te, exist_ok=True)
    os.makedirs(va, exist_ok=True)

    fls = os.listdir(src_dir)
    tr_fls, temp_fls = train_test_split(fls, te_sz=(te_sz + va_sz))
    te_fls, va_fls = train_test_split(temp_fls, te_sz=(va_sz / (te_sz + va_sz)))

    for fl in tr_fls:
        shutil.copy(os.path.join(src_dir, fl), os.path.join(tr, fl))
    for fl in te_fls:
        shutil.copy(os.path.join(src_dir, fl), os.path.join(te, fl))
    for fl in va_fls:
        shutil.copy(os.path.join(src_dir, fl), os.path.join(va, fl))

def Ex_locBinPatt_des(I):
    r = 1
    n_p = 8 * r
    locBinPatt = feature.local_binary_pattern(I, n_p, r, method="uniform")
    H, _ = n.histogram(locBinPatt.ravel(), bins=n.arange(0, n_p + 3), range=(0, n_p + 2))
    H = H.astype("float")
    H /= (H.sum() + 1e-7)
    return H


def process_images_in_directory(dir_root):
    locBinPatt_des = []
    for F_name in os.listdir(dir_root):
        if F_name.endswith(".jpg"):
            I_root = os.path.join(dir_root, F_name)
            I = cv2.imread(I_root, cv2.IMREAD_GRAYSCALE)
            rs_I = cv2.resize(I, (64, 128))
            locBinPatt_destor = Ex_locBinPatt_des(rs_I)
            locBinPatt_des.append(locBinPatt_destor)
    return locBinPatt_des

def process_category_images(face_or_nonface, tr, va, te):
    tr_lbps = process_images_in_directory(os.path.join(tr, face_or_nonface))
    va_lbps = process_images_in_directory(os.path.join(va, face_or_nonface))
    te_lbps = process_images_in_directory(os.path.join(te, face_or_nonface))

    tr_dFrame = p.DataFrame(tr_lbps)
    va_dFrame = p.DataFrame(va_lbps)
    te_dFrame = p.DataFrame(te_lbps)

    tr_dFrame.to_csv(f'/storage/nandani/ACV1/LBP/Train{face_or_nonface}.csv', index=False)
    va_dFrame.to_csv(f'/storage/nandani/ACV1/LBP/Val{face_or_nonface}.csv', index=False)
    te_dFrame.to_csv(f'/storage/nandani/ACV1/LBP/Test{face_or_nonface}.csv', index=False)

   
    for phase in ['Train', 'Val', 'Test']:
        dFrame = p.read_csv(f'/storage/nandani/ACV1/LBP/{phase}{face_or_nonface}.csv')
        dFrame['label'] = face_or_nonface
        dFrame.to_csv(f'/storage/nandani/ACV1/LBP/l1{phase}{face_or_nonface}.csv', index=False)


face_dir = "/storage/nandani/ACV1/face"
Nface_dir = "/storage/nandani/ACV1/nonface"
tr_dir = "/storage/nandani/ACV1/HOG/Train"
te_dir = "/storage/nandani/ACV1/HOG/Test"
va_dir = "/storage/nandani/ACV1/HOG/Val"


spt_I(face_dir, os.path.join(tr_dir, "face"), os.path.join(te_dir, "face"), os.path.join(va_dir, "face"))
spt_I(Nface_dir, os.path.join(tr_dir, "nonface"), os.path.join(te_dir, "nonface"), os.path.join(va_dir, "nonface"))


process_category_images('face', tr_dir, va_dir, te_dir)
process_category_images('nonface', tr_dir, va_dir, te_dir)

print("save CSV file of Images")


tr_dFrame = p.read_csv('/storage/nandani/ACV1/LBP/LBPTrain - Sheet1.csv')
va_dFrame = p.read_csv('/storage/nandani/ACV1/LBP/LBPval - Sheet1.csv')
te_dFrame = p.read_csv('/storage/nandani/ACV1/LBP/LBPtest - Sheet1.csv')

tr_x, tr_y = tr_dFrame.drop('label', axis=1), tr_dFrame['label']
va_x, va_y = va_dFrame.drop('label', axis=1), va_dFrame['label']
te_x, te_y = te_dFrame.drop('label', axis=1), te_dFrame['label']

Cls_SVM = SVC(kernel='linear', random_state=42)
Cls_SVM.fit(tr_x, tr_y)

pred_va_y = Cls_SVM.predict(va_x)
va_acc = accuracy_score(va_y, pred_va_y)
print(f'Accuracy on the validation set: {va_acc:.2f}')

pred_te_y = Cls_SVM.predict(te_x)
te_acc = accuracy_score(te_y, pred_te_y)
print(f'Accuracy on the test set: {te_acc:.2f}')

def detect_faces(I, svm_model):
    w_s = (64, 64)
    step = 20
    for y in range(0, I.shape[0] - w_s[1], step):
        for x in range(0, I.shape[1] - w_s[0], step):
            w = I[y:y + w_s[1], x:x + w_s[0]]
            r_w = cv2.resize(w, (64, 128))
            locBinPatt_destor = Ex_locBinPatt_des(r_w) 
            prediction = svm_model.predict(locBinPatt_destor.reshape(1, -1))
            if prediction == 'face':  
                cv2.rectangle(I, (x, y), (x + w_s[0], y + w_s[1]), (0, 255, 0), 2)
    return I

input_I_paths = ['/storage/nandani/ACV1/Face/image_357.jpg',
                     '/storage/nandani/ACV1/LBP/Test/nonface/image_295.jpg',
                     '/storage/nandani/ACV1/LBP/Test/face/image_163.jpg']

for I_root in input_I_paths:
    input_I = cv2.imread(I_root)
    gray_I = cv2.cvtColor(input_I, cv2.COLOR_BGR2GRAY)
    output_I = detect_faces(gray_I, Cls_SVM)
    cv2_imshow(output_I)
