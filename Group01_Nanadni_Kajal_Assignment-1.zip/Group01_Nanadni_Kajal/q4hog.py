#Human_Non-Human


import os
import cv2
import numpy as n
import pandas as p
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score
import joblib
from sklearn.model_selection import train_test_split

def spt_I(src_dir, tr_dir, te_dir, va_dir, te_sz=0.1, va_sz=0.2):
    fls = os.listdir(src_dir)
    tr_fls, temp_files = train_test_split(fls, te_sz=(te_sz + va_sz))
    te_fls, va_fls = train_test_split(temp_files, te_sz=(va_sz / (te_sz + va_sz)))

    for fl in tr_fls:
        shutil.copy(os.path.join(src_dir, fl), os.path.join(tr_dir, fl))
    for fl in te_fls:
        shutil.copy(os.path.join(src_dir, fl), os.path.join(te_dir, fl))
    for fl in va_fls:
        shutil.copy(os.path.join(src_dir, fl), os.path.join(va_dir, fl))

def grad_cal(I):
    xg = cv2.Sobel(I, cv2.CV_64F, 1, 0, ksize=3)
    yg = cv2.Sobel(I, cv2.CV_64F, 0, 1, ksize=3)
    return xg, yg

def Mag_Ori_cal(xg, yg):
    Mag = n.sqrt(xg**2 + yg**2)
    Ori = n.arctan2(yg, xg) * 180 / n.pi
    return Mag, Ori

def histo(Ori, Mag, nob=9):
    B = n.linspace(0, 180, nob + 1)
    H, _ = n.histogram(Ori, B=B, weights=Mag)
    return H

def Blk_nor(Blk):
    Blk_norm = n.sqrt(Blk.sum()**2 + 1e-5)
    return Blk / Blk_norm

def Ex_hog_des(I):
    xg, yg = grad_cal(I)
    Mag, Ori = Mag_Ori_cal(xg, yg)

    cs = 8
    bs = 2
    nob = 9

    deptr = []
    for c in range(0, I.shape[0], cs):
        for k in range(0, I.shape[1], cs):
            cell_Oris = Ori[c:c+cs, k:k+cs]
            cell_Mags = Mag[c:c+cs, k:k+cs]
            H = histo(cell_Oris, cell_Mags, nob)
            deptr.extend(H)

    deptr = n.array(deptr)
    deptr = deptr.reshape((deptr.size // (bs**2 * nob), bs**2 * nob))

    for c in range(deptr.shape[0]):
        for k in range(deptr.shape[1]):
            deptr[c, k] = Blk_nor(deptr[c, k])

    return deptr.flatten()

def process_Is_in_directory(dir_root):
    H_deptr = []

    for F_name in os.listdir(dir_root):
        if F_name.endswith(".jpg"):
            I_path = os.path.join(dir_root, F_name)
            I = cv2.imread(I_path, cv2.IMREAD_GRAYSCALE)
            resized_I = cv2.resize(I, (64, 128))

            des_hog = Ex_hog_des(resized_I)
            H_deptr.append(des_hog)

    return H_deptr

spt_I(human_directory, os.path.join(tr_dir, "human"), os.path.join(te_dir, "human"), os.path.join(va_dir, "human"))

spt_I(nonhuman_directory, os.path.join(tr_dir, "nonhuman"), os.path.join(te_dir, "nonhuman"), os.path.join(va_dir, "nonhuman"))

hog_tr = process_Is_in_directory(os.path.join(tr_dir, "/storage/nandani/ACV1/HOG/Train/human"))
hog_va = process_Is_in_directory(os.path.join(va_dir, "/storage/nandani/ACV1/HOG/Val/human"))
hog_te = process_Is_in_directory(os.path.join(te_dir, "/storage/nandani/ACV1/HOG/Test/human"))

hog_te_dFrame = p.DataFrame(hog_tr)
hog_va_dFrame = p.DataFrame(hog_va)
hog_te_dFrame = p.DataFrame(hog_te)

hog_te_dFrame.to_csv('/storage/nandani/ACV1/HOG/train_human_hog.csv', index=False)
hog_va_dFrame.to_csv('/storage/nandani/ACV1/HOG/val_human_hog.csv', index=False)
hog_te_dFrame.to_csv('/storage/nandani/ACV1/HOG/test_human_hog.csv', index=False)

hog_tr = process_Is_in_directory(os.path.join(tr_dir, "/storage/nandani/ACV1/HOG/Train/nonhuman"))
hog_va = process_Is_in_directory(os.path.join(va_dir, "/storage/nandani/ACV1/HOG/Train/nonhuman"))
hog_te = process_Is_in_directory(os.path.join(te_dir, "/storage/nandani/ACV1/HOG/Train/nonhuman"))

hog_te_dFrame = p.DataFrame(hog_tr)
hog_va_dFrame = p.DataFrame(hog_va)
hog_te_dFrame = p.DataFrame(hog_te)

hog_te_dFrame.to_csv('/storage/nandani/ACV1/HOG/train_nonhuman_hog.csv', index=False)
hog_va_dFrame.to_csv('/storage/nandani/ACV1/HOG/val_nonhuman_hog.csv', index=False)
hog_te_dFrame.to_csv('/storage/nandani/ACV1/HOG/test_nonhuman_hog.csv', index=False)

tr_dFrame = p.read_csv('/storage/nandani/ACV1/HOG/HOGTrain - Sheet1.csv')
va_dFrame = p.read_csv('/storage/nandani/ACV1/HOG/HOGVal - Sheet1.csv')
te_dFrame = p.read_csv('/storage/nandani/ACV1/HOG/HOGTest - Sheet1.csv')

tr_x, tr_y = tr_dFrame.drop('label', axis=1), tr_dFrame['label']
va_x, va_y = va_dFrame.drop('label', axis=1), va_dFrame['label']
te_x, te_y = te_dFrame.drop('label', axis=1), te_dFrame['label']

cls_SVM = SVC(kernel='linear', random_state=42)
cls_SVM.fit(tr_x, tr_y)

tr_acc = accuracy_score(tr_y, cls_SVM.predict(tr_x))
print(f'Training Accuracy: {tr_acc:.2f}')
va_acc = accuracy_score(va_y, cls_SVM.predict(va_x))
print(f'Validation Accuracy: {va_acc:.2f}')
te_acc = accuracy_score(te_y, cls_SVM.predict(te_x))
print(f'Test Accuracy: {te_acc:.2f}')

joblib.dump(cls_SVM, '/storage/nandani/ACV1/HOG/svm_model.pkl')
print("saved svm_model")

def H_det(I):
    H_deted = []
    for (x, y, w) in sliding_window(I):
        r_w = cv2.resize(w, (64, 128))
        des_hog = Ex_hog_des(r_w)
        pred = cls_SVM.predict(des_hog.reshape(1, -1))
        if pred == 'human':
            H_deted.append((x, y, x + 64, y + 128))  # Assuming fixed w size
    return H_deted

input_I = cv2.imread('/storage/nandani/ACV1/HOG/Test/human/I_131.jpg')
gray_I = cv2.cvtColor(input_I, cv2.COLOR_BGR2GRAY)
H_deted = H_det(gray_I)

for (x1, y1, x2, y2) in H_deted:
    cv2.rectangle(input_I, (x1, y1), (x2, y2), (0, 255, 0), 2)

cv2.imshow('Detected Humans', input_I)
cv2.waitKey(0)
cv2.destroyAllWindows()

