#MNIST AE_model

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.d import DataLoader, TensorDataset
import pandas as p
import numpy as n
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as pyp


tr_dFrame = p.read_csv('/storage/nandani/ACV1/mnist_train.csv')
te_dFrame = p.read_csv('/storage/nandani/ACV1/mnist_test.csv')

tr_x = tr_dFrame.iloc[:, 1:].values.astype('float32')
tr_y = tr_dFrame.iloc[:, 0].values.astype('int')

te_x = te_dFrame.values.astype('float32')

tr_x /= 255.0
te_x /= 255.0

ncl = 10
1h_tr_y = n.zeros((tr_y.shape[0], ncl))
1h_tr_y[n.arange(tr_y.shape[0]), tr_y] = 1

tr_x, va_x, tr_y, va_y = train_test_split(tr_x, 1h_tr_y, test_size=0.2, random_state=42)

ten_tr_x = torch.tensor(tr_x)
ten_tr_y = torch.tensor(tr_y, dtype=torch.float32)

ten_va_x = torch.tensor(va_x)
ten_va_y = torch.tensor(va_y, dtype=torch.float32)

class AE_model(nn.Module):
    def __init__(self, ip_sz, hd_sz):
        super(AE_model, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(ip_sz, hd_sz),
            nn.Tanh()
        )
        self.decoder = nn.Sequential(
            nn.Linear(hd_sz, ip_sz),
        )

    def forward(self, Z):
        Z = self.encoder(Z)
        Z = self.decoder(Z)
        return Z

ip_sz = tr_x.shape[1]
hd_sz = 64
bt_sz = 64
lr = 0.001
ep = 100

tr_data = TensorDataset(ten_tr_x, ten_tr_x)  
tr_load = DataLoader(tr_data, bt_sz=bt_sz, shuffle=True)

va_data = TensorDataset(ten_va_x, ten_va_x) 
va_load = DataLoader(va_data, bt_sz=bt_sz, shuffle=False)

ae = AE_model(ip_sz, hd_sz)

crit = nn.MSELoss()
opt = optim.Adam(ae.parameters(), lr=lr)

tr_Ls = []
va_Ls = []

# Training loop
for e in range(ep):
    ep_tr_l = 0.0  
    for d, _ in tr_load:  
        d = d.view(d.size(0), -1)  
        opt.zero_grad() 

        
        op = ae(d)

        
        L = crit(op, d)

       
        L.backward()

        
        opt.step()

        ep_tr_l += L.item()  

   
    print(f"Epoch {e + 1}/{ep}, Loss: {ep_tr_l / len(tr_load)}")

 
    tr_Ls.append(ep_tr_l / len(tr_load))


torch.save(ae.state_dict(), '/storage/nandani/ACV1/autoencoder_weights.pth')


pyp.plot(tr_Ls, label='Training Loss')
pyp.xlabel('Epoch')
pyp.ylabel('Loss')
pyp.legend()
pyp.show()

ae.load_state_dict(torch.load('/storage/nandani/ACV1/autoencoder_weights.pth'))

te_x_resh = te_x[:, 1:].reshape(-1, 28 * 28)


te_data = TensorDataset(torch.tensor(te_x_resh), torch.tensor(te_x_resh))
te_load = DataLoader(te_data, bt_sz=bt_sz, shuffle=False)


te_L = 0.0
ae.eval()
for d, _ in te_load:
    d = d.view(d.size(0), -1)
    op = ae(d)
    te_L += crit(op, d).item()

te_L /= len(te_load)

print(f"Test Loss: {te_L}")


