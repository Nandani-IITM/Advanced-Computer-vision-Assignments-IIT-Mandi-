import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import Dataset, DataLoader
import pandas as p
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as mpt

class model_mlp(nn.Module):
    def __init__(self, ip_sz, hd_sz, op_sz, pre_wt):
        super(model_mlp, self).__init__()

        self.l1 = nn.Linear(ip_sz, hd_sz)
        self.l1.weight.data = pre_wt['encoder.0.weight']
        self.l1.bias.data = pre_wt['encoder.0.bias']
        self.sigmoid = nn.Sigmoid()
        
        self.l2 = nn.Linear(hd_sz, op_sz)
        self.l2.weight.data = pre_wt['decoder.0.weight']
        self.l2.bias.data = pre_wt['decoder.0.bias']

    def forward(self, Z):
        Z = self.l1(Z)
        Z = self.sigmoid(Z)
        Z = self.l2(Z)
        return Z

def Model_training(M, crtn, optm, tr_ldr, va_ldr, ep=10):
    tr_ls = []
    va_ls = []
    tr_accs = []
    va_accs = []

    for e in range(ep):
        M.Model_training()
        tr_L = 0.0
        tr_crt = 0
        tr_ttl = 0

        for ips, tgt in tr_ldr:
            optm.zero_grad()
            ops = M(ips)
            L = crtn(ops, tgt)
            L.backward()
            optm.step()
            tr_L += L.item()

            _, pred = torch.max(ops.data, 1)
            tr_ttl += tgt.size(0)
            tr_crt += (pred == tgt).sum().item()

        avg_train_loss = tr_L / len(tr_ldr)
        train_accuracy = tr_crt / tr_ttl
        tr_ls.append(avg_train_loss)
        tr_accs.append(train_accuracy)

        
        M.eval()
        va_L = 0.0
        va_crt = 0
        va_ttl = 0

        with torch.no_grad():
            for ips, tgt in va_ldr:
                ops = M(ips)
                L = crtn(ops, tgt)
                va_L += L.item()

                _, pred = torch.max(ops.data, 1)
                va_ttl += tgt.size(0)
                va_crt += (pred == tgt).sum().item()

        
        va_L_avg = va_L / len(va_ldr)
        va_acc = va_crt / va_ttl
        va_ls.append(va_L_avg)
        va_accs.append(va_acc)

        print(f'Epoch [{e+1}/{ep}], Train Loss: {avg_train_loss:.4f}, Valid Loss: {va_L_avg:.4f}, Train Accuracy: {train_accuracy:.4f}, Valid Accuracy: {va_acc:.4f}')

    return tr_ls, va_ls, tr_accs, va_accs

def plot_curves(tr_ls, va_ls, tr_accs, va_accs):
    fig, (axis1, axis2) = mpt.subplots(2, 1, figsize=(10, 8))

    # Plot losses
    axis1.plot(tr_ls, label='Train Loss', color='tab:red')
    axis1.plot(va_ls, label='Valid Loss', linestyle='dashed', color='tab:blue')
    axis1.set_xlabel('Epochs')
    axis1.set_ylabel('Loss')
    axis1.legend()

    # Plot accuracies
    axis2.plot(tr_accs, label='Train Accuracy', color='tab:red')
    axis2.plot(va_accs, label='Valid Accuracy', linestyle='dashed', color='tab:blue')
    axis2.set_xlabel('Epochs')
    axis2.set_ylabel('Accuracy')
    axis2.legend()

    mpt.tight_layout()
    mpt.show()

class Data_mnist(Dataset):
    def __init__(self, d, lbs):
        self.d = d #Dataset
        self.lbs = lbs

    def __len__(self):
        return len(self.d)

    def __getitem__(self, idx):
        return self.d[idx], self.lbs[idx]

tr_dFrame = p.read_csv('/storage/nandani/ACV1/mnist_train.csv')
te_dFrame = p.read_csv('/storage/nandani/ACV1/mnist_test.csv')

tr_lbs = tr_dFrame.iloc[:, 0].values
tr_I = tr_dFrame.iloc[:, 1:].values / 255.0  

te_lbs = te_dFrame.iloc[:, 0].values
te_I = te_dFrame.iloc[:, 1:].values / 255.0  

tr_I, va_I, tr_lbs, va_lbs = train_test_split(
    tr_I, tr_lbs, test_size=0.2, random_state=42
)

tr_dt = torch.tensor(tr_I, dtype=torch.float32)
tr_lbs = torch.tensor(tr_lbs, dtype=torch.long)

va_dt = torch.tensor(va_I, dtype=torch.float32)
va_lbs = torch.tensor(va_lbs, dtype=torch.long)

te_dt = torch.tensor(te_I, dtype=torch.float32)
te_lbs = torch.tensor(te_lbs, dtype=torch.long)

bt_sz = 32

tr_dset = Data_mnist(tr_dt, tr_lbs)
tr_ldr = DataLoader(tr_dset, bt_sz=bt_sz, shuffle=True)

va_dset = Data_mnist(va_dt, va_lbs)
va_ldr = DataLoader(va_dset, bt_sz=bt_sz, shuffle=False)

te_dset = Data_mnist(te_dt, te_lbs)
te_ldr = DataLoader(te_dset, bt_sz=bt_sz, shuffle=False)

torch.manual_seed(42)

ip_sz = 784
hd_sz = 64
op_sz = 10

M = MLPModel(ip_sz, hd_sz, op_sz)
crtn = nn.CrossEntropyLoss()
optm = optim.SGD(M.parameters(), lr=0.001)

tr_ls, va_ls, tr_accs, va_accs = Model_Training(M, crtn, optm, tr_ldr, va_ldr, ep=100)

plot_curves(tr_ls, va_ls, tr_accs, va_accs)

M.eval()
crt = 0
ttl = 0
with torch.no_grad():
    for ips, lbs in te_ldr:
        ops = M(ips)
        _, pred = torch.max(ops, 1)
        ttl += lbs.size(0)
        crt += (pred == lbs).sum().item()

accuracy = crt / ttl
print(f'Test Accuracy: {accuracy:.4f}')

