#CIFAR10

#(I) 3 CONV + 1 FC layers CNN


import torch
import torch.nn as nn
import torch.optim as optim
import torchvision
import torchvision.transforms as transforms
from torch.utils.data import DataLoader
import matplotlib.pyplot as p

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

ep = 100
bt_sz = 64
lr = 0.001

train_transform = transforms.Compose([
    transforms.RandomHorizontalFlip(),
    transforms.RandomVerticalFlip(),
    transforms.RandomRotation(20),
    transforms.ToTensor(),
    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
])

test_transform = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5)),
])

tr_dt = torchvision.datasets.CIFAR10(root='/storage/nandani/ACV1/data', train=True, download=True, transform=train_transform)
te_dt = torchvision.datasets.CIFAR10(root='/storage/nandani/ACV1/data', train=False, download=True, transform=test_transform)

tr_ldr = DataLoader(dataset=tr_dt, batch_size=bt_sz, shuffle=True)
te_ldr = DataLoader(dataset=te_dt, batch_size=bt_sz, shuffle=False)

class SimpleCNN(nn.Module):
    def __init__(self):
        super(SimpleCNN, self).__init__()
        self.conv1 = nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1)
        self.relu1 = nn.ReLU()
        self.pool1 = nn.MaxPool2d(kernel_size=2, stride=2)

        self.conv2 = nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1)
        self.relu2 = nn.ReLU()
        self.pool2 = nn.MaxPool2d(kernel_size=2, stride=2)

        self.conv3 = nn.Conv2d(128, 256, kernel_size=3, stride=1, padding=1)
        self.relu3 = nn.ReLU()
        self.pool3 = nn.MaxPool2d(kernel_size=2, stride=2)

        self.fc = nn.Linear(256 * 4 * 4, 10)

    def forward(self, Z):
        Z = self.pool1(self.relu1(self.conv1(Z)))
        Z = self.pool2(self.relu2(self.conv2(Z)))
        Z = self.pool3(self.relu3(self.conv3(Z)))
        Z = Z.view(-1, 256 * 4 * 4)
        Z = self.fc(Z)
        return Z

M = SimpleCNN().to(device)
crtn = nn.CrossEntropyLoss()
optm = optim.Adam(M.parameters(), lr=lr)

tr_ls = []
tr_accs = []
va_ls = []
va_accs = []

for e in range(ep):
    M.train()
    run_L = 0.0
    tr_crt = 0
    tr_ttl = 0

    for i, (I, lbs) in enumerate(tr_ldr):
        I, lbs = I.to(device), lbs.to(device)

        
        ops = M(I)
        L = crtn(ops, lbs)

        
        optm.zero_grad()
        L.backward()
        optm.step()

        run_L += L.item()
        _, pred = torch.max(ops, 1)
        tr_ttl += lbs.size(0)
        tr_crt += (pred == lbs).sum().item()

    
    tr_acc = 100 * tr_crt / tr_ttl
    tr_L = run_L / len(tr_ldr)

    
    M.eval()
    va_l = 0.0
    va_crt = 0
    va_ttl = 0

    with torch.no_grad():
        for I, lbs in te_ldr:
            I, lbs = I.to(device), lbs.to(device)
            ops = M(I)
            L = crtn(ops, lbs)

            va_l += L.item()
            _, pred = torch.max(ops, 1)
            va_ttl += lbs.size(0)
            va_crt += (pred == lbs).sum().item()

   
    va_acc = 100 * va_crt / va_ttl
    va_l /= len(te_ldr)

    
    print(f'Epoch [{e+1}/{ep}], '
          f'Train Loss: {tr_L:.4f}, Train Accuracy: {tr_acc:.2f}%, '
          f'Validation Loss: {va_l:.4f}, Validation Accuracy: {va_acc:.2f}%')

    tr_ls.append(tr_L)
    tr_accs.append(tr_acc)
    va_ls.append(va_l)
    va_accs.append(va_acc)

M.eval()
te_crt = 0
te_ttl = 0
with torch.no_grad():
    for I, lbs in te_ldr:
        I, lbs = I.to(device), lbs.to(device)
        ops = M(I)
        _, pred = torch.max(ops, 1)
        te_ttl += lbs.size(0)
        te_crt += (pred == lbs).sum().item()

te_acc = 100 * te_crt / te_ttl
print(f'Test Accuracy: {te_acc:.2f}%')

p.figure(figsize=(10, 5))
p.subplot(1, 2, 1)
p.plot(tr_ls, label='Train Loss')
p.plot(va_ls, label='Validation Loss')
p.xlabel('Epochs')
p.ylabel('Loss')
p.legend()

p.subplot(1, 2, 2)
p.plot(tr_accs, label='Train Accuracy')
p.plot(va_accs, label='Validation Accuracy')
p.xlabel('Epochs')
p.ylabel('Accuracy (%)')
p.legend()

